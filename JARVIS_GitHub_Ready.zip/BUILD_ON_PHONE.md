1. Create a PUBLIC GitHub repository.
2. Upload this whole project with folders intact.
3. Open Actions.
4. Run Build JARVIS APK.
5. Wait for the green check.
6. Open the run -> Artifacts -> JARVIS-AI-Advanced-debug.
7. Extract and install app-debug.apk.
