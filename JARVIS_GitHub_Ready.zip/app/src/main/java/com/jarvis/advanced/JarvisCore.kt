package com.jarvis.advanced

enum class TaskState { RECEIVED, PLANNING, EXECUTING, RECOVERING, VERIFYING, COMPLETED, FAILED }
data class MissionStep(val title:String,var done:Boolean=false)
data class Mission(val request:String,val steps:MutableList<MissionStep>,var state:TaskState=TaskState.RECEIVED)

enum class ModelRole { FAST, REASONING, CODING, VISION, RESEARCH }
data class Route(val role:ModelRole,val adapter:String)

class JarvisEngine {
    var online=true; private set
    fun setOnline(v:Boolean){online=v}
    fun plan(request:String):Mission = Mission(request, mutableListOf(
        MissionStep("Understand request"), MissionStep("Decompose task"), MissionStep("Select model/tool"),
        MissionStep("Execute primary path"), MissionStep("Retry with fallback if needed"), MissionStep("Verify result")
    ), TaskState.PLANNING)
    fun route(request:String):Route { val t=request.lowercase(); return when {
        listOf("code","coding","program","kotlin","android").any(t::contains)->Route(ModelRole.CODING,"Coding adapter")
        listOf("image","photo","camera","ocr","qr").any(t::contains)->Route(ModelRole.VISION,"Vision adapter")
        listOf("search","research","news","web").any(t::contains)->Route(ModelRole.RESEARCH,"Web adapter")
        listOf("why","analyze","plan").any(t::contains)->Route(ModelRole.REASONING,"Reasoning adapter")
        else->Route(ModelRole.FAST,"Fast adapter")
    }}
    fun verify(m:Mission):Mission { m.steps.forEach{it.done=true}; m.state=TaskState.COMPLETED; return m }
}

class OpenRouterConfig(var baseUrl:String="https://openrouter.ai/api", var model:String="openrouter/free", var apiKey:String="")
class MemoryStore { private val items=mutableListOf<String>(); fun add(s:String){items+=s}; fun clear(){items.clear()}; fun all():List<String> = items.toList() }
