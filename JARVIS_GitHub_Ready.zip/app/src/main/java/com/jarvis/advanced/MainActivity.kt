package com.jarvis.advanced

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Bg=Color(0xFF050A12); private val Panel=Color(0xFF0B1522); private val Panel2=Color(0xFF10243A)
private val Cyan=Color(0xFF22D3EE); private val Blue=Color(0xFF60A5FA); private val Teal=Color(0xFF2DD4BF); private val Text=Color(0xFFE6F4FF); private val Muted=Color(0xFF8AA2B5)

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{JarvisApp()}}}

@Composable fun JarvisApp(){
 val context=LocalContext.current; val engine=remember{JarvisEngine()}; val memory=remember{MemoryStore()}
 var locked by remember{mutableStateOf(true)}; var tab by remember{mutableIntStateOf(0)}; var online by remember{mutableStateOf(true)}
 var mission by remember{mutableStateOf<Mission?>(null)}; var chat by remember{mutableStateOf(listOf("JARVIS: Systems initialized. How can I help?"))}
 val tts=remember{TextToSpeech(context){}}; val mic=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
 DisposableEffect(Unit){onDispose{tts.shutdown()}}
 MaterialTheme(colorScheme=darkColorScheme(primary=Cyan,background=Bg,surface=Panel,onBackground=Text,onSurface=Text)){
  if(locked) LockScreen{locked=false;if(ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)mic.launch(Manifest.permission.RECORD_AUDIO)}
  else Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Panel){listOf("Home" to Icons.Default.Home,"Chat" to Icons.Default.Chat,"Mission" to Icons.Default.Bolt,"Settings" to Icons.Default.Settings).forEachIndexed{i,p->NavigationBarItem(tab==i,{tab=i},{Icon(p.second,null)},{Text(p.first)})}}}){pad->Box(Modifier.fillMaxSize().padding(pad)){
   when(tab){0->Dashboard(online){cmd->mission=engine.plan(cmd);memory.add(cmd);chat=chat+"YOU: $cmd"+"JARVIS: Mission planned.";tab=2}
   1->Chat(chat){cmd->mission=engine.plan(cmd);memory.add(cmd);chat=chat+"YOU: $cmd"+"JARVIS: Task decomposed and routed."}
   2->MissionView(mission)
   3->Settings(online,{online=!online;engine.setOnline(online)},{memory.clear();chat=listOf("JARVIS: Private memory cleared.")})}
  }}}
 }
}

@Composable fun LockScreen(onUnlock:()->Unit){Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){Text("THE FUTURE IS NOW",color=Cyan,fontWeight=FontWeight.Bold);Text("JARVIS",color=Text,style=MaterialTheme.typography.displaySmall);Text("AI ADVANCED SYSTEM",color=Muted);Orb(Modifier.fillMaxWidth().height(310.dp));Text("JARVIS ONLINE",color=Teal,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center);Spacer(Modifier.height(22.dp));Button(onClick=onUnlock,Modifier.fillMaxWidth().height(54.dp),colors=ButtonDefaults.buttonColors(containerColor=Cyan,contentColor=Bg)){Icon(Icons.Default.Fingerprint,null);Spacer(Modifier.width(8.dp));Text("UNLOCK JARVIS",fontWeight=FontWeight.Bold)};Spacer(Modifier.height(18.dp));Text("STAY FOCUSED • STAY AHEAD",color=Muted,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}}

@Composable fun Orb(modifier:Modifier){val a by rememberInfiniteTransition(label="orb").animateFloat(.9f,1.08f,infiniteRepeatable(tween(1400),RepeatMode.Reverse),label="pulse");Canvas(modifier){val c=Offset(size.width/2,size.height/2);val r=minOf(size.width,size.height)*.22f*a;drawCircle(Brush.radialGradient(listOf(Color(0xFFB8F7FF),Cyan,Color(0xFF123C6B),Color.Transparent)),r*2.2f,c);drawCircle(Cyan,r,c);drawCircle(Blue.copy(.5f),r*1.6f,c,style=Stroke(2.dp.toPx()));drawCircle(Cyan.copy(.3f),r*2f,c,style=Stroke(1.dp.toPx()))}}

@Composable fun Dashboard(online:Boolean,onCommand:(String)->Unit){LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){item{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("JARVIS AI",color=Cyan,fontWeight=FontWeight.Bold);Text("Good evening, Operator",color=Text,style=MaterialTheme.typography.headlineSmall);Text("Advanced neural assistant",color=Muted)}Status(if(online)"SYSTEM ONLINE" else "OFFLINE",online)}};item{Orb(Modifier.fillMaxWidth().height(230.dp))};item{Command(onCommand)};item{Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){Tile("Search",Icons.Default.Search,Modifier.weight(1f)){onCommand("Search the web")};Tile("Weather",Icons.Default.Cloud,Modifier.weight(1f)){onCommand("Show weather")};Tile("Calendar",Icons.Default.Event,Modifier.weight(1f)){onCommand("Show calendar")}}};item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(15.dp)){Text("MASTER AI ORCHESTRATOR",color=Cyan,fontWeight=FontWeight.Bold);Text("Understand → Plan → Route → Execute → Retry → Verify",color=Muted);Spacer(Modifier.height(8.dp));LinearProgressIndicator({0.92f},Modifier.fillMaxWidth(),color=Cyan,trackColor=Panel2)}}}}}

@Composable fun Command(onCommand:(String)->Unit){var t by remember{mutableStateOf("")};Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).border(1.dp,Panel2,RoundedCornerShape(18.dp)),verticalAlignment=Alignment.CenterVertically){TextField(t,{t=it},Modifier.weight(1f),placeholder={Text("Type a command…",color=Muted)},colors=TextFieldDefaults.colors(focusedContainerColor=Color.Transparent,unfocusedContainerColor=Color.Transparent,focusedIndicatorColor=Color.Transparent,unfocusedIndicatorColor=Color.Transparent));IconButton({if(t.isNotBlank())onCommand(t)}){Icon(Icons.Default.Send,null,tint=Cyan)}}}

@Composable fun Tile(label:String,icon:ImageVector,modifier:Modifier,onClick:()->Unit){Card(onClick=onClick,modifier=modifier,colors=CardDefaults.cardColors(Panel),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(11.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=Cyan);Text(label,color=Text,style=MaterialTheme.typography.labelSmall)}}}
@Composable fun Status(s:String,on:Boolean){Row(Modifier.background(Panel2,RoundedCornerShape(50)).padding(horizontal=10.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(7.dp).clip(CircleShape).background(if(on)Teal else Color.Red));Spacer(Modifier.width(6.dp));Text(s,color=Muted,style=MaterialTheme.typography.labelSmall)}}

@Composable fun Chat(messages:List<String>,onSend:(String)->Unit){var t by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(18.dp)){Text("JARVIS CHAT",color=Cyan,fontWeight=FontWeight.Bold);Text("Neural conversation",color=Text,style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(10.dp));LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){items(messages){Card(colors=CardDefaults.cardColors(Panel),shape=RoundedCornerShape(15.dp)){Text(it,color=Text,Modifier.padding(13.dp))}}};Row(verticalAlignment=Alignment.CenterVertically){TextField(t,{t=it},Modifier.weight(1f),placeholder={Text("Message JARVIS…")});IconButton({if(t.isNotBlank()){onSend(t);t=""}}){Icon(Icons.Default.Send,null,tint=Cyan)}}}}

@Composable fun MissionView(m:Mission?){Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){Text("MISSION CENTER",color=Cyan,fontWeight=FontWeight.Bold);Text("Task execution",color=Text,style=MaterialTheme.typography.headlineSmall);if(m==null)Text("No active mission",color=Muted) else {Text(m.request,color=Text,fontWeight=FontWeight.SemiBold);Text("STATE: ${m.state}",color=Teal);m.steps.forEachIndexed{i,s->Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(14.dp)).padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text("${i+1}",color=Cyan,fontWeight=FontWeight.Bold);Spacer(Modifier.width(10.dp));Text(s.title,color=Text,Modifier.weight(1f));Icon(if(s.done)Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,null,tint=if(s.done)Teal else Muted)}}}}}

@Composable fun Settings(online:Boolean,toggle:()->Unit,clear:()->Unit){Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("SETTINGS",color=Cyan,fontWeight=FontWeight.Bold);Text("Preferences & Configuration",color=Text,style=MaterialTheme.typography.headlineSmall);Setting(Icons.Default.Security,"Runtime permissions","Microphone and network access");Setting(Icons.Default.AutoGraph,"AI routing","Fast / reasoning / coding / vision / research");Setting(Icons.Default.Memory,"Private memory","Clear local conversation memory",clear);Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(16.dp)).padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("System online",color=Text,fontWeight=FontWeight.SemiBold);Text("Local orchestration state",color=Muted,style=MaterialTheme.typography.bodySmall)}Switch(online,{toggle()})};Text("OpenRouter default: https://openrouter.ai/api",color=Muted,style=MaterialTheme.typography.labelSmall)}}
@Composable fun Setting(icon:ImageVector,title:String,sub:String,onClick:(()->Unit)?=null){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(16.dp)).padding(13.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Cyan);Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(title,color=Text,fontWeight=FontWeight.SemiBold);Text(sub,color=Muted,style=MaterialTheme.typography.bodySmall)};if(onClick!=null)TextButton(onClick){Text("CLEAR")}}}
