# JARVIS AI Advanced

Full Android Compose starter for the JARVIS project: futuristic lock screen, orb dashboard, chat, Mission Center, settings, task orchestration core, model routing, memory and OpenRouter configuration architecture.

Build target: Android 26+, compile/target SDK 35, AGP 8.7.3, Gradle 8.9, JDK 17.

No API key is embedded. Configure your provider at runtime or through a secure backend.

## Build
`gradle :app:assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub
The included workflow builds the debug APK on a public GitHub repository. Open Actions -> Build JARVIS APK -> Run workflow -> download the artifact.
