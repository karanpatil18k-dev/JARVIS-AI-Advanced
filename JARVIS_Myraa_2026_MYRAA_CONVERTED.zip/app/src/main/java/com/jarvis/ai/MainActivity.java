package com.jarvis.ai;

import android.Manifest;
import android.app.*;
import android.provider.CalendarContract;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import android.util.Base64;
import org.json.*;

public class MainActivity extends Activity {
    WebView web; JarvisBridge bridge;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(2,8,18));
        web=new WebView(this); web.setBackgroundColor(Color.rgb(2,8,18));
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient()); bridge=new JarvisBridge(); web.addJavascriptInterface(bridge,"JarvisNative");
        web.loadUrl("file:///android_asset/www/index.html"); setContentView(web);
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77);
    }
    public class JarvisBridge {
      TextToSpeech tts; SpeechRecognizer sr; android.content.SharedPreferences sp;
      JarvisBridge(){ sp=getSharedPreferences("jarvis",MODE_PRIVATE); tts=new TextToSpeech(MainActivity.this,s->{}); }
      @JavascriptInterface public String getConfig(){ return "{\"baseUrl\":\""+esc(sp.getString("baseUrl","https://openrouter.ai/api/v1"))+"\",\"model\":\""+esc(sp.getString("model","openrouter/free"))+"\",\"hasKey\":"+(sp.getString("key","").length()>0)+"}"; }
      @JavascriptInterface public void saveConfig(String base,String model,String key){ sp.edit().putString("baseUrl",base.trim()).putString("model",model.trim()).putString("key",key.trim()).apply(); }
      @JavascriptInterface public void speak(String text){ if(tts!=null) tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarvis"); }
      @JavascriptInterface public void stopSpeaking(){ if(tts!=null) tts.stop(); }
      @JavascriptInterface public void listen(){ runOnUiThread(()->startListen()); }
      void startListen(){ try{ if(sr!=null) sr.destroy(); sr=SpeechRecognizer.createSpeechRecognizer(MainActivity.this); Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); sr.setRecognitionListener(new RecognitionListener(){ public void onReadyForSpeech(Bundle p){js("voiceState('listening')");} public void onBeginningOfSpeech(){js("voiceState('listening')");} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){js("voiceState('processing')");} public void onError(int e){js("voiceState('error')");} public void onResults(Bundle x){ArrayList<String> a=x.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()) js("voiceResult("+JSONObject.quote(a.get(0))+")");} public void onPartialResults(Bundle x){ArrayList<String>a=x.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty())js("voicePartial("+JSONObject.quote(a.get(0))+")");} public void onEvent(int a,Bundle b){} }); sr.startListening(i);}catch(Exception e){js("voiceState('error')");} }
      @JavascriptInterface public void action(String a,String arg){ try{ Intent i=null; if(a.equals("web")) i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+URLEncoder.encode(arg,"UTF-8"))); else if(a.equals("maps")) i=new Intent(Intent.ACTION_VIEW,Uri.parse("google.navigation:q="+URLEncoder.encode(arg,"UTF-8"))); else if(a.equals("youtube")) i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query="+URLEncoder.encode(arg,"UTF-8"))); else if(a.equals("calendar")){i=new Intent(Intent.ACTION_INSERT);i.setData(CalendarContract.Events.CONTENT_URI);i.putExtra(CalendarContract.Events.TITLE,arg);} if(i!=null)startActivity(i);}catch(Exception e){Toast.makeText(MainActivity.this,"Action unavailable",Toast.LENGTH_SHORT).show();}}
      @JavascriptInterface public void ai(String body){ final String base=sp.getString("baseUrl","https://openrouter.ai/api/v1"); final String model=sp.getString("model","openrouter/free"); final String key=sp.getString("key",""); new Thread(()->{try{if(key.isEmpty()){js("aiError('API key not configured. Open Settings.')");return;} URL u=new URL(base.replaceAll("/$","")+"/chat/completions"); HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Content-Type","application/json");c.setConnectTimeout(12000);c.setReadTimeout(45000);c.setDoOutput(true); JSONObject in=new JSONObject(body); JSONArray msgs=in.optJSONArray("messages"); JSONObject req=new JSONObject();req.put("model",model);req.put("stream",false);req.put("messages",msgs); try(OutputStream o=c.getOutputStream()){o.write(req.toString().getBytes(StandardCharsets.UTF_8));} int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String r=read(is); if(code<200||code>=300){js("aiError("+JSONObject.quote("Provider HTTP "+code+": "+r.substring(0,Math.min(300,r.length())))+")");return;} JSONObject out=new JSONObject(r); String text=out.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content",""); js("aiResult("+JSONObject.quote(text)+")");}catch(Exception e){js("aiError("+JSONObject.quote(e.getMessage()==null?"Network error":e.getMessage())+")");}}).start();}
      String read(InputStream in)throws Exception{if(in==null)return"";BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);return b.toString();}
      String esc(String s){return s.replace("\\","\\\\").replace("\"","\\\"");} void js(String x){runOnUiThread(()->web.evaluateJavascript("(function(){try{"+x+"}catch(e){}})();",null));}
    }
    @Override protected void onDestroy(){if(bridge!=null&&bridge.tts!=null)bridge.tts.shutdown();if(bridge!=null&&bridge.sr!=null)bridge.sr.destroy();super.onDestroy();}
}
