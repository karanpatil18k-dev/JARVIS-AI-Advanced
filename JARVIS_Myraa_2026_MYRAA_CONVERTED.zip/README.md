# JARVIS Myraa 2026

A source-project rebuild using the supplied MYRAA APK's visual character assets (idle/talking/thinking) and a JARVIS 2026 master-agent UI.

## Functional foundations
- Real OpenRouter-compatible chat API connection (runtime-configured)
- Master-agent task planning/routing UI
- Mission + agent monitor
- Native Android SpeechRecognizer input
- Native Android Text-to-Speech output
- Web search / YouTube / Maps / Calendar intents
- Marathi/Hindi/English/Hinglish prompts
- No fake "mission completed" response
- GitHub Actions APK build

## Important
The supplied MYRAA.zip is a compiled APK, not an Android source project. Therefore this repository is a clean source rebuild that reuses the supplied Myraa visual assets; it does not pretend to recover the original proprietary source code.

API keys are entered at runtime in Settings and are not included in this repository.
